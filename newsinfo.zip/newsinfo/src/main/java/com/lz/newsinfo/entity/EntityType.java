package com.lz.newsinfo.entity;

/**
 * Created by nowcoder on 2016/7/7.
 */
public class EntityType {
    public static int ENTITY_NEWS = 1;
}
