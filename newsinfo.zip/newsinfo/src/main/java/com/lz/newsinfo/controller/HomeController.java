package com.lz.newsinfo.controller;


import com.lz.newsinfo.entity.HostHolder;
import com.lz.newsinfo.entity.News;
import com.lz.newsinfo.entity.ViewObject;
import com.lz.newsinfo.service.NewsService;
import com.lz.newsinfo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class HomeController {

    @Autowired
    NewsService newsService;

    @Autowired
    UserService userService;


    @Autowired
    HostHolder hostHolder;

    private List<ViewObject> getNews(int userId,int offset,int limit){
        List<News> newsList = newsService.getLatesNews(userId,offset,limit);
        //视图展现对象
        List<ViewObject> vos = new ArrayList<>();
        //将数据传至视图展示对象中
        for(News news : newsList){
            ViewObject vo = new ViewObject();
            vo.set("news",news);
            vo.set("user",userService.getUser(news.getUserId()));
            vos.add(vo);
        }
        return vos;
    }

    @RequestMapping(path = {"/", "/index"},method = {RequestMethod.GET,RequestMethod.POST})
    public String index(Model model){
        //将视图展现对象添加到model中
        model.addAttribute("vos",getNews(0,0,10));

        return "home";
    }

    @RequestMapping(path = {"/user/{userId}/"},method = {RequestMethod.GET,RequestMethod.POST})
    public String userIndex(Model model, @PathVariable("userId")int userId
                                           , @RequestParam(value = "pop",defaultValue="0")int pop){
        //将视图展现对象添加到model中
        model.addAttribute("vos",getNews(userId,0,10));
        model.addAttribute("pop",pop);
        return "home";
    }

}
