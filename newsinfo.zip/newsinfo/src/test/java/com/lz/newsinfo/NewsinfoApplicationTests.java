package com.lz.newsinfo;

import org.junit.Test;
import org.springframework.boot.test.SpringApplicationConfiguration;

@SpringApplicationConfiguration
public class NewsinfoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
