package com.nowcoder;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Test1 {
    public static void main(String[] args) {
        Scanner in= new Scanner(System.in);
        int count = in.nextInt();
        Scanner sc= new Scanner(System.in);
        List<String> out = new LinkedList<String>();
         while(count!=0){
            int a1 = sc.nextInt();
            int b1 = sc.nextInt();
            int c1 = sc.nextInt();
            int d1 = sc.nextInt();

            int a2 = sc.nextInt();
            int b2 = sc.nextInt();
            int c2 = sc.nextInt();
            int d2 = sc.nextInt();
            if(Math.abs(c1-a1)==Math.abs(d1-b1)&&Math.abs(b2-a2)==Math.abs(d2-c2)&&Math.abs(c1-a1)==Math.abs(d2-c2)){
               out.add("Yes");
            }else{
                out.add("No");
            }
            count--;
        }
        for(String t :out){
            System.out.println(t);
        }
    }
}
