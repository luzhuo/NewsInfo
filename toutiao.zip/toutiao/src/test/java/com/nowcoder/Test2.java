package com.nowcoder;

import java.util.Scanner;

public class Test2 {
    public static void main(String[] args) {
        Scanner in= new Scanner(System.in);
        long count = in.nextLong();

        if(count%2==0){

        }else if(count%2==1){

        }
    }
}
